<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              piwebsolution.com
 * @since             1.1
 * @package           Pisol_Pickup_Location_Date_Time
 *
 * @wordpress-plugin
 * Plugin Name:       custom shortcode hook
 * Plugin URI:        piwebsolution.com
 * Description:       custom shortcode hook
 * Version:           1.1
 * Author:            PI Websolution
 * Author URI:        piwebsolution.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pisol-pickup-location-date-time
 * Domain Path:       /languages
 * WC tested up to: 7.2.2
 */


add_filter('pi_ppscw_cal_position_filter', function($pos){
	return 'pisol_calculator';
});

add_shortcode( 'pisol_calculator', function(){
	if(function_exists('is_product') && is_product()){
		do_action('pisol_calculator');
	}
} );